// Regras simples de triagem automática.
const URGENT_WORDS = ['risco', 'urgente', 'apagado', 'obstruindo'];

export const classifyUrgency = (text) =>
  URGENT_WORDS.some((word) => text.toLowerCase().includes(word)) ? 'Alta' : 'Média';

// Gera o próximo protocolo sequencial (REC-2026-887, ...).
export const nextProtocol = (reports) => {
  const last = Math.max(...reports.map((r) => Number(r.id.split('-')[2])));
  return `REC-2026-${last + 1}`;
};
