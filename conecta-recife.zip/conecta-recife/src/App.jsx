import { useState } from 'react';
import useReports from './hooks/useReports';
import { scrollToSection } from './utils/scroll';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import Hero from './components/sections/Hero';
import Features from './components/sections/Features';
import OdsImpact from './components/sections/OdsImpact';
import About from './components/sections/About';
import Dashboard from './components/dashboard/Dashboard';
import NewReportModal from './components/dashboard/NewReportModal';

export default function App() {
  const board = useReports();
  const [newReportOpen, setNewReportOpen] = useState(false);

  const openNewReport = () => setNewReportOpen(true);
  const closeNewReport = () => setNewReportOpen(false);

  const handleCreate = (data) => {
    board.addReport(data);
    board.resetFilters(); // garante que a nova denúncia apareça na tabela
    closeNewReport();
    scrollToSection('painel-servidor');
  };

  return (
    <>
      <Header onNewReport={openNewReport} />
      <main>
        <Hero />
        <Features />
        <OdsImpact />
        <Dashboard board={board} onNewReport={openNewReport} />
        <About />
      </main>
      <Footer />
      {newReportOpen && <NewReportModal onClose={closeNewReport} onSubmit={handleCreate} />}
    </>
  );
}
