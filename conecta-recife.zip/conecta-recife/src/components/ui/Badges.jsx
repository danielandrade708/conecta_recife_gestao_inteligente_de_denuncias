const URGENCY_STYLES = {
  Alta: ['bg-rose-100 text-rose-700', 'bg-rose-600'],
  Média: ['bg-amber-100 text-amber-700', 'bg-amber-600'],
  Baixa: ['bg-emerald-100 text-emerald-700', 'bg-emerald-600'],
};

const STATUS_STYLES = {
  Resolvido: 'border-emerald-200 bg-emerald-50 text-emerald-700',
  'Em Análise': 'border-sky-200 bg-sky-50 text-sky-700',
  'Em Aberto': 'border-slate-200 bg-slate-100 text-slate-700',
};

export function UrgencyBadge({ level }) {
  const [box, dot] = URGENCY_STYLES[level];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-bold ${box}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${dot}`} />
      {level}
    </span>
  );
}

export function StatusBadge({ status }) {
  return (
    <span className={`rounded-lg border px-2.5 py-1 text-xs font-semibold ${STATUS_STYLES[status]}`}>
      {status}
    </span>
  );
}
