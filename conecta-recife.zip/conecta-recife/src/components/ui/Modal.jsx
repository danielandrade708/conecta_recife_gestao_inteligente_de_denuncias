import { useEffect } from 'react';

// Modal genérico: fecha com ESC ou clicando fora.
export default function Modal({ title, subtitle, onClose, maxWidth = 'max-w-lg', children }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className={`flex max-h-full w-full ${maxWidth} flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl`}
      >
        <div className="flex shrink-0 items-center justify-between bg-brand-navy p-6 text-white">
          <div>
            {subtitle && <span className="block font-mono text-xs text-brand-emeraldLight">{subtitle}</span>}
            <h3 className="text-lg font-bold">{title}</h3>
          </div>
          <button onClick={onClose} aria-label="Fechar" className="text-xl text-slate-400 hover:text-white">
            <i className="fa-solid fa-xmark" />
          </button>
        </div>
        <div className="overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}
