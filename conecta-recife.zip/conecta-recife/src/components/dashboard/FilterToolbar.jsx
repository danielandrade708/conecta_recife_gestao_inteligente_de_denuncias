import { CATEGORIES } from '../../data/content';

const URGENCY_OPTIONS = [
  ['Todos', 'Todas as Urgências'],
  ['Alta', 'Alta Urgência'],
  ['Média', 'Média Urgência'],
  ['Baixa', 'Baixa Urgência'],
];

const FILTER_BUTTONS = [{ value: 'Todos', short: 'Todas' }, ...CATEGORIES];

export default function FilterToolbar({ filters, onChange }) {
  return (
    <div className="mb-6 flex flex-col items-stretch justify-between gap-4 rounded-2xl border border-slate-200/80 bg-white p-4 shadow-sm lg:flex-row lg:items-center">
      <div className="relative w-full lg:w-80">
        <i className="fa-solid fa-magnifying-glass absolute left-3.5 top-3 text-sm text-slate-400" />
        <input
          type="text"
          value={filters.search}
          onChange={(e) => onChange('search', e.target.value)}
          placeholder="Buscar por protocolo, bairro ou palavra..."
          aria-label="Buscar denúncias"
          className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 pl-10 pr-4 text-sm transition-all focus:border-brand-emerald focus:bg-white focus:outline-none"
        />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <span className="mr-1 text-xs font-bold text-slate-500">Categoria:</span>
        {FILTER_BUTTONS.map((cat) => {
          const active = filters.category === cat.value;
          return (
            <button
              key={cat.value}
              onClick={() => onChange('category', cat.value)}
              aria-pressed={active}
              className={`rounded-lg border px-3 py-1.5 text-xs font-semibold transition-all ${
                active ? 'border-brand-navy bg-brand-navy text-white' : 'border-slate-200 bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {cat.short}
            </button>
          );
        })}
      </div>

      <select
        value={filters.urgency}
        onChange={(e) => onChange('urgency', e.target.value)}
        aria-label="Filtrar por urgência"
        className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-700 focus:border-brand-emerald focus:outline-none lg:w-auto"
      >
        {URGENCY_OPTIONS.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
      </select>
    </div>
  );
}
