import Modal from '../ui/Modal';
import { StatusBadge, UrgencyBadge } from '../ui/Badges';

function Info({ label, children }) {
  return (
    <div>
      <span className="mb-1 block text-xs font-semibold uppercase text-slate-500">{label}</span>
      <div className="text-sm font-bold text-slate-800">{children}</div>
    </div>
  );
}

export default function ReportDetailsModal({ report, onClose, onResolve }) {
  return (
    <Modal subtitle={report.id} title={`${report.categoria} em ${report.bairro}`} onClose={onClose}>
      <div className="space-y-4 p-6">
        <div className="grid grid-cols-2 gap-4">
          <Info label="Categoria">{report.categoria}</Info>
          <Info label="Bairro">{report.bairro}</Info>
          <Info label="Nível Urgência"><UrgencyBadge level={report.urgencia} /></Info>
          <Info label="Status Atual"><StatusBadge status={report.status} /></Info>
        </div>

        <div className="border-t border-slate-100 pt-3">
          <span className="mb-1 block text-xs font-semibold uppercase text-slate-500">Descrição Relatada pelo Cidadão</span>
          <p className="rounded-xl border border-slate-200/80 bg-slate-50 p-3 text-sm text-slate-700">{report.descricao}</p>
        </div>

        <div className="rounded-xl border border-brand-emerald/30 bg-brand-softMint p-4">
          <span className="mb-1 block text-xs font-bold uppercase text-brand-emerald">
            <i className="fa-solid fa-robot mr-1" /> Recomendação do Sistema IA
          </span>
          <p className="text-xs font-medium text-slate-800">{report.recomendacao}</p>
        </div>
      </div>

      <div className="flex justify-end gap-3 border-t border-slate-200 bg-slate-50 px-6 py-4">
        <button onClick={onClose} className="rounded-xl px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-200">Fechar</button>
        {report.status !== 'Resolvido' && (
          <button onClick={onResolve} className="rounded-xl bg-brand-emerald px-5 py-2 text-xs font-bold text-white shadow-sm hover:bg-brand-emeraldHover">
            Marcar como Resolvido
          </button>
        )}
      </div>
    </Modal>
  );
}
