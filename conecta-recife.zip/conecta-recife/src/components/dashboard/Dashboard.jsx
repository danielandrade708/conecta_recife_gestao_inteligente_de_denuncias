import { useState } from 'react';
import StatsBar from './StatsBar';
import FilterToolbar from './FilterToolbar';
import ReportsTable from './ReportsTable';
import ReportDetailsModal from './ReportDetailsModal';

export default function Dashboard({ board, onNewReport }) {
  const { allReports, visibleReports, stats, filters, updateFilter, resetFilters, resolveReport } = board;
  const [selectedId, setSelectedId] = useState(null);
  const selected = allReports.find((r) => r.id === selectedId);

  const closeDetails = () => setSelectedId(null);
  const handleResolve = () => {
    resolveReport(selectedId);
    closeDetails();
  };

  return (
    <section id="painel-servidor" className="scroll-mt-20 bg-brand-lightBg py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div>
            <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-brand-emerald">Demonstração Interativa</span>
            <h2 className="text-3xl font-extrabold text-brand-navy">Painel de Operações & Triagem</h2>
            <p className="mt-1 text-sm text-slate-600">Simulação em tempo real para servidores e gestores municipais do Conecta Recife.</p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <button onClick={resetFilters} className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-600 transition-colors hover:text-slate-900">
              <i className="fa-solid fa-rotate-left mr-1" /> Redefinir Filtros
            </button>
            <button onClick={onNewReport} className="flex items-center gap-1.5 rounded-lg bg-brand-emerald px-4 py-2 text-xs font-semibold text-white shadow-sm transition-all hover:bg-brand-emeraldHover">
              <i className="fa-solid fa-plus" /> Nova Denúncia
            </button>
          </div>
        </div>

        <StatsBar stats={stats} />
        <FilterToolbar filters={filters} onChange={updateFilter} />
        <ReportsTable reports={visibleReports} onSelect={setSelectedId} onReset={resetFilters} />
      </div>

      {selected && <ReportDetailsModal report={selected} onClose={closeDetails} onResolve={handleResolve} />}
    </section>
  );
}
