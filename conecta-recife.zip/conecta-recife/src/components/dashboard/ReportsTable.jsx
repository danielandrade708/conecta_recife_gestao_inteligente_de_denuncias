import { StatusBadge, UrgencyBadge } from '../ui/Badges';

const COLUMNS = ['Protocolo', 'Categoria', 'Bairro / Local', 'Nível de Urgência', 'Status', 'Ação Recomendada'];

export default function ReportsTable({ reports, onSelect, onReset }) {
  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-left text-sm text-slate-700">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs font-bold uppercase text-slate-500">
            <tr>
              {COLUMNS.map((col, i) => (
                <th key={col} className={`px-6 py-4 ${i === COLUMNS.length - 1 ? 'text-right' : ''}`}>{col}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {reports.map((r) => (
              <tr key={r.id} onClick={() => onSelect(r.id)} className="cursor-pointer transition-colors hover:bg-slate-50">
                <td className="px-6 py-4 font-mono text-xs font-bold text-slate-900">{r.id}</td>
                <td className="px-6 py-4 font-medium text-slate-800">{r.categoria}</td>
                <td className="px-6 py-4 font-semibold text-slate-700">{r.bairro}</td>
                <td className="px-6 py-4"><UrgencyBadge level={r.urgencia} /></td>
                <td className="px-6 py-4"><StatusBadge status={r.status} /></td>
                <td className="px-6 py-4 text-right">
                  <button className="inline-flex items-center gap-1 text-xs font-bold text-brand-emerald hover:underline">
                    Ver detalhes <i className="fa-solid fa-chevron-right text-[10px]" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {reports.length === 0 && (
        <div className="py-12 text-center">
          <i className="fa-solid fa-folder-open mb-3 text-4xl text-slate-300" />
          <p className="font-medium text-slate-600">Nenhuma denúncia encontrada para os filtros selecionados.</p>
          <button onClick={onReset} className="mt-3 text-xs font-bold text-brand-emerald hover:underline">Limpar filtros</button>
        </div>
      )}
    </div>
  );
}
