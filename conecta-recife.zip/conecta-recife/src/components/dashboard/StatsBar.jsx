const CARDS = [
  { key: 'total', label: 'Total Registrado', icon: 'fa-inbox', caption: 'Denúncias no sistema', tone: 'text-slate-500', value: 'text-brand-navy' },
  { key: 'critical', label: 'Prioridade Alta', icon: 'fa-triangle-exclamation', caption: 'Demanda atenção imediata', tone: 'text-rose-500', value: 'text-rose-600' },
  { key: 'pending', label: 'Em Análise / Aberto', icon: 'fa-clock-rotate-left', caption: 'Em processo de atendimento', tone: 'text-amber-500', value: 'text-amber-600' },
  { key: 'solved', label: 'Resoluções', icon: 'fa-circle-check', caption: 'Concluídas com êxito', tone: 'text-emerald-500', value: 'text-emerald-600' },
];

function StatCard({ label, icon, caption, tone, valueTone, value }) {
  return (
    <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm">
      <div className={`mb-2 flex items-center justify-between gap-2 ${tone}`}>
        <span className="text-xs font-bold uppercase tracking-wider">{label}</span>
        <i className={`fa-solid ${icon}`} />
      </div>
      <div className={`text-3xl font-black ${valueTone}`}>{value}</div>
      <span className="text-xs text-slate-500">{caption}</span>
    </div>
  );
}

export default function StatsBar({ stats }) {
  return (
    <div className="mb-8 grid grid-cols-1 gap-4 min-[480px]:grid-cols-2 lg:grid-cols-4">
      {CARDS.map(({ key, value, ...card }) => (
        <StatCard key={key} {...card} valueTone={value} value={stats[key]} />
      ))}
    </div>
  );
}
