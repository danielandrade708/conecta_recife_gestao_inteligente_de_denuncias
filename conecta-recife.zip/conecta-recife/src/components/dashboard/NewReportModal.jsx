import { useState } from 'react';
import Modal from '../ui/Modal';
import { BAIRROS, CATEGORIES } from '../../data/content';

const fieldClass =
  'w-full rounded-xl border border-slate-300 bg-slate-50 p-2.5 text-xs font-medium text-slate-800 focus:border-brand-emerald focus:outline-none';

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-bold text-slate-700">{label}</span>
      {children}
    </label>
  );
}

export default function NewReportModal({ onClose, onSubmit }) {
  const [form, setForm] = useState({ categoria: CATEGORIES[0].value, bairro: BAIRROS[0], descricao: '' });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
  };

  return (
    <Modal title="Cadastrar Denúncia via Conecta" maxWidth="max-w-md" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4 p-6">
        <Field label="Categoria do Problema">
          <select name="categoria" value={form.categoria} onChange={handleChange} className={fieldClass}>
            {CATEGORIES.map((c) => <option key={c.value}>{c.value}</option>)}
          </select>
        </Field>
        <Field label="Bairro do Recife">
          <select name="bairro" value={form.bairro} onChange={handleChange} className={fieldClass}>
            {BAIRROS.map((b) => <option key={b}>{b}</option>)}
          </select>
        </Field>
        <Field label="Descrição Detalhada">
          <textarea name="descricao" value={form.descricao} onChange={handleChange} required rows={3} placeholder="Descreva a situação observada..." className={fieldClass} />
        </Field>
        <button type="submit" className="w-full rounded-xl bg-brand-emerald py-3 text-xs font-bold text-white shadow-md transition-all hover:bg-brand-emeraldHover">
          Enviar Denúncia
        </button>
      </form>
    </Modal>
  );
}
