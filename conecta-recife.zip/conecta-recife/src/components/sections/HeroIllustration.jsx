const PINS = [[142, 302, '#EF4444'], [242, 342, '#10B981'], [372, 312, '#F59E0B']];

// Ilustração vetorial: painel com gráfico, indicador e mapa com marcadores.
export default function HeroIllustration() {
  return (
    <svg viewBox="0 0 500 500" fill="none" className="h-full w-full drop-shadow-md" role="img" aria-label="Painel com gráfico, indicadores e mapa de denúncias">
      <rect x="40" y="60" width="420" height="360" rx="20" fill="white" stroke="#1E293B" strokeWidth="8" />
      <rect x="40" y="60" width="420" height="50" rx="12" fill="#0F172A" />
      {['#EF4444', '#F59E0B', '#10B981'].map((c, i) => <circle key={c} cx={70 + i * 25} cy="85" r="8" fill={c} />)}

      <rect x="70" y="140" width="160" height="110" rx="12" fill="#F1F5F9" stroke="#E2E8F0" strokeWidth="3" />
      <path d="M 85 220 Q 110 170 135 190 T 185 160 T 215 210" stroke="#10B981" strokeWidth="5" strokeLinecap="round" />
      <circle cx="185" cy="160" r="6" fill="#0F172A" />

      <rect x="250" y="140" width="180" height="110" rx="12" fill="#ECFDF5" stroke="#10B981" strokeWidth="3" />
      <circle cx="310" cy="195" r="30" stroke="#10B981" strokeWidth="12" strokeDasharray="140 50" />
      <rect x="360" y="170" width="50" height="8" rx="4" fill="#0F172A" />
      <rect x="360" y="188" width="35" height="8" rx="4" fill="#94A3B8" />
      <rect x="360" y="206" width="45" height="8" rx="4" fill="#10B981" />

      <rect x="70" y="270" width="360" height="120" rx="12" fill="#F8FAFC" stroke="#CBD5E1" strokeWidth="3" />
      {[310, 350].map((y) => <line key={y} x1="70" y1={y} x2="430" y2={y} stroke="#E2E8F0" strokeWidth="2" />)}
      {[180, 310].map((x) => <line key={x} x1={x} y1="270" x2={x} y2="390" stroke="#E2E8F0" strokeWidth="2" />)}
      {PINS.map(([cx, cy, c]) => (
        <g key={cx}>
          <circle cx={cx} cy={cy} r="12" fill={c} opacity="0.3" />
          <circle cx={cx} cy={cy} r="6" fill={c} />
        </g>
      ))}
    </svg>
  );
}
