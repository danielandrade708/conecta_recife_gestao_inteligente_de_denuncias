import { FEATURES } from '../../data/content';
import { scrollToSection } from '../../utils/scroll';

function FeatureCard({ icon, title, text }) {
  return (
    <div className="group rounded-2xl border border-slate-200/90 bg-brand-lightBg p-8 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl">
      <div className="mb-6 flex h-14 w-14 items-center justify-center rounded-2xl border border-slate-200 bg-white text-2xl text-brand-navy shadow-sm transition-colors group-hover:border-brand-emerald group-hover:bg-brand-emerald group-hover:text-white">
        <i className={`fa-solid ${icon}`} />
      </div>
      <h3 className="mb-3 text-xl font-bold text-brand-navy">{title}</h3>
      <p className="text-sm leading-relaxed text-slate-600">{text}</p>
    </div>
  );
}

export default function Features() {
  return (
    <section id="visao-geral" className="scroll-mt-20 border-y border-slate-200/80 bg-white py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto mb-14 max-w-3xl text-center">
          <h2 className="text-3xl font-extrabold tracking-tight text-brand-navy">Desenvolva competências que fazem a diferença</h2>
          <p className="mt-3 text-base text-slate-600">
            A plataforma une inteligência geográfico-estatística para superar os desafios operacionais do Conecta Recife e modernizar o atendimento ao cidadão recifense.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          {FEATURES.map((feature) => <FeatureCard key={feature.title} {...feature} />)}
        </div>

        <div className="mt-12 text-center">
          <button onClick={() => scrollToSection('painel-servidor')} className="rounded-full bg-brand-emerald px-8 py-3.5 text-base font-bold text-white shadow-md transition-all hover:scale-105 hover:bg-brand-emeraldHover">
            Comece sua próxima etapa de desenvolvimento
          </button>
        </div>
      </div>
    </section>
  );
}
