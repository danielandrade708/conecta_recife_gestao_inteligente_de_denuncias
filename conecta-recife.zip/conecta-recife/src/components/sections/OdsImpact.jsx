import { ODS_GOALS } from '../../data/content';

function OdsCard({ number, title, text, goal, box, tag }) {
  return (
    <div className="flex flex-col items-start gap-6 rounded-2xl border border-slate-700/80 bg-slate-800/90 p-8 sm:flex-row">
      <div className={`flex h-20 w-20 flex-shrink-0 flex-col items-center justify-center rounded-2xl font-black text-white shadow-lg ${box}`}>
        <span className="text-xs font-semibold uppercase tracking-wider">ODS</span>
        <span className="text-3xl">{number}</span>
      </div>
      <div>
        <h3 className="mb-2 text-xl font-bold text-white">{title}</h3>
        <p className="mb-4 text-sm leading-relaxed text-slate-300">{text}</p>
        <span className={`inline-block rounded-full border px-3 py-1 text-xs font-semibold ${tag}`}>{goal}</span>
      </div>
    </div>
  );
}

export default function OdsImpact() {
  return (
    <section id="ods-impacto" className="scroll-mt-20 bg-slate-900 py-16 text-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-12 flex flex-col items-start justify-between gap-8 md:flex-row md:items-center">
          <div>
            <span className="mb-2 block text-xs font-bold uppercase tracking-widest text-brand-emeraldLight">Compromisso Global</span>
            <h2 className="text-3xl font-extrabold tracking-tight">Alinhamento com Objetivos de Desenvolvimento Sustentável (ODS)</h2>
          </div>
          <p className="max-w-md text-sm text-slate-400">
            O aprimoramento da gestão de denúncias contribui diretamente para as metas da Agenda 2030 da ONU no município do Recife.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
          {ODS_GOALS.map((ods) => <OdsCard key={ods.number} {...ods} />)}
        </div>
      </div>
    </section>
  );
}
