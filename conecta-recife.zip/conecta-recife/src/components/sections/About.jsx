const CHECKLIST = [
  'Classificação preditiva por IA',
  'Matriz de severidade e risco municipal',
  'Painel Unificado de Decisão para Servidores',
];

const BENEFITS = [
  { icon: 'fa-bolt text-amber-500', title: 'Redução de Lead-Time', text: 'Redução de até 65% no tempo médio entre o registro da denúncia e seu encaminhamento ao departamento responsável.' },
  { icon: 'fa-bullseye text-brand-emerald', title: 'Ação Preventiva', text: 'Identificação de focos recorrentes para realização de manutenções preventivas antes do agravamento crítico.' },
];

export default function About() {
  return (
    <section id="sobre" className="scroll-mt-20 border-t border-slate-200 bg-white py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12">
          <div className="rounded-3xl border border-brand-emerald/30 bg-brand-softMint p-8 lg:col-span-5">
            <span className="mb-2 block text-xs font-bold uppercase tracking-wider text-brand-emerald">Contexto Institucional</span>
            <h3 className="mb-4 text-2xl font-bold text-brand-navy">Fragmentação do Tratamento de Denúncias</h3>
            <p className="mb-6 text-sm leading-relaxed text-slate-700">
              As denúncias recebidas via Conecta Recife demandam grande esforço operacional de triagem. A falta de sistematização histórica e geográfica limita a capacidade da gestão pública de agir preventivamente.
            </p>
            <ul className="space-y-3 border-t border-brand-emerald/20 pt-4">
              {CHECKLIST.map((item) => (
                <li key={item} className="flex items-center gap-3 text-sm font-medium text-slate-800">
                  <i className="fa-solid fa-circle-check text-brand-emerald" />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-6 lg:col-span-7">
            <h2 className="text-3xl font-extrabold text-brand-navy">Solução Proposta para a Gestão Pública</h2>
            <p className="text-base leading-relaxed text-slate-600">
              Ao integrar os dados brutos recebidos pelo Conecta Recife a algoritmos de priorização e visualização cartográfica, transformamos reclamações esparsas em um mapa tático de inteligência urbana.
            </p>
            <div className="grid grid-cols-1 gap-6 pt-2 sm:grid-cols-2">
              {BENEFITS.map((b) => (
                <div key={b.title} className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
                  <i className={`fa-solid ${b.icon} mb-2 text-2xl`} />
                  <h4 className="mb-1 font-bold text-slate-900">{b.title}</h4>
                  <p className="text-xs text-slate-600">{b.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
