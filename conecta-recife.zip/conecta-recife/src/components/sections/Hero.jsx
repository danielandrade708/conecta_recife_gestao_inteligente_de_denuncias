import { CATEGORIES } from '../../data/content';
import { scrollToSection } from '../../utils/scroll';
import HeroIllustration from './HeroIllustration';

export default function Hero() {
  return (
    <section id="inicio" className="relative scroll-mt-20 overflow-hidden bg-brand-lightBg py-12 md:py-20 lg:py-24">
      <div className="dot-pattern pointer-events-none absolute right-6 top-6 hidden h-32 w-32 opacity-60 lg:block" />
      <div className="dot-pattern pointer-events-none absolute bottom-6 left-6 hidden h-32 w-32 opacity-60 lg:block" />

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12">
          <div className="space-y-6 lg:col-span-7">
            <div className="inline-flex items-center gap-2 rounded-full border border-slate-300/80 bg-slate-200/70 px-3.5 py-1.5 text-xs font-semibold text-slate-700">
              <span className="h-2 w-2 animate-pulse rounded-full bg-brand-emerald" />
              Desafio Conecta Recife • Publicado em 23/01/2026
            </div>

            <h1 className="text-4xl font-extrabold leading-tight tracking-tight text-brand-navy sm:text-5xl lg:text-6xl">
              Transformando denúncias em{' '}
              <span className="underline decoration-brand-emerald decoration-4 underline-offset-4">inteligência urbana</span>
            </h1>

            <p className="max-w-2xl text-lg leading-relaxed text-slate-600">
              Plataforma inteligente de triagem, priorização e análise espacial das demandas do Conecta Recife. Agilizando a ação da gestão municipal e otimizando serviços públicos em toda a cidade.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-4">
              <button onClick={() => scrollToSection('painel-servidor')} className="flex items-center gap-3 rounded-2xl bg-brand-navy px-8 py-4 text-base font-bold text-white shadow-lg transition-all hover:-translate-y-0.5 hover:bg-slate-800 hover:shadow-xl">
                <span>Explorar Painel</span>
                <i className="fa-solid fa-arrow-right" />
              </button>
              <button onClick={() => scrollToSection('visao-geral')} className="rounded-2xl border-2 border-brand-emerald/40 bg-white px-8 py-4 text-base font-bold text-brand-emerald shadow-sm transition-all hover:border-brand-emerald hover:bg-brand-softMint">
                Conhecer a solução
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2 border-t border-slate-200/80 pt-6 text-xs font-medium">
              <span className="mr-1 font-bold text-slate-700">Áreas atendidas:</span>
              {CATEGORIES.map((cat) => (
                <span key={cat.value} className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-700 shadow-sm">
                  <i className={`fa-solid ${cat.icon} ${cat.color} mr-1.5`} />
                  {cat.value}
                </span>
              ))}
            </div>
          </div>

          <div className="relative lg:col-span-5">
            <div className="relative rounded-3xl border border-slate-200 bg-gradient-to-tr from-brand-emerald/10 to-blue-50/50 p-6 shadow-xl">
              <div className="mx-auto aspect-square w-full max-w-md">
                <HeroIllustration />
              </div>
              <div className="absolute -bottom-4 right-2 flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-5 py-3 shadow-xl">
                <span className="h-3 w-3 animate-ping rounded-full bg-emerald-500" />
                <div>
                  <p className="text-xs font-medium text-slate-500">Priorização Ativa</p>
                  <p className="text-sm font-bold text-slate-900">IA de Triagem On-line</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
