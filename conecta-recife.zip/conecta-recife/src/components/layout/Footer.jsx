import { NAV_LINKS } from '../../data/content';

const CATEGORY_LINKS = ['Iluminação Pública', 'Limpeza Urbana & Entulhos', 'Mobilidade e Trânsito', 'Meio Ambiente & Arborização'];

function FooterColumn({ title, children }) {
  return (
    <div>
      <h5 className="mb-4 text-sm font-bold text-white">{title}</h5>
      {children}
    </div>
  );
}

export default function Footer() {
  return (
    <footer className="border-t border-slate-800 bg-brand-navy py-12 text-slate-400">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-12 grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-4">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-emerald text-base text-white">
                <i className="fa-solid fa-city" />
              </span>
              <span className="text-lg font-bold text-white">Conecta Recife</span>
            </div>
            <p className="text-xs leading-relaxed">
              Inovação aberta e gestão orientada a dados para transformar os serviços municipais da cidade do Recife.
            </p>
          </div>

          <FooterColumn title="Navegação">
            <ul className="space-y-2 text-xs">
              {NAV_LINKS.map((link) => (
                <li key={link.id}><a href={`#${link.id}`} className="transition-colors hover:text-white">{link.label}</a></li>
              ))}
            </ul>
          </FooterColumn>

          <FooterColumn title="Categorias do Conecta">
            <ul className="space-y-2 text-xs">
              {CATEGORY_LINKS.map((name) => <li key={name}>{name}</li>)}
            </ul>
          </FooterColumn>

          <FooterColumn title="Realização">
            <p className="mb-3 text-xs">Prefeitura do Recife • Desafio Conecta Recife 2026</p>
            <div className="flex gap-2">
              {['ODS 11', 'ODS 16'].map((ods) => (
                <span key={ods} className="rounded border border-slate-700 bg-slate-800 px-2.5 py-1 text-[10px] font-semibold text-slate-300">{ods}</span>
              ))}
            </div>
          </FooterColumn>
        </div>

        <div className="flex flex-col items-center justify-between gap-4 border-t border-slate-800 pt-8 text-center text-xs text-slate-500 sm:flex-row sm:text-left">
          <p>&copy; 2026 Conecta Recife Intelligence. Todos os direitos reservados.</p>
          <p>Desenvolvido para otimização do atendimento ao cidadão recifense.</p>
        </div>
      </div>
    </footer>
  );
}
