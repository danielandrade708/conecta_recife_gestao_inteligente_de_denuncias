import { useState } from 'react';
import { NAV_LINKS } from '../../data/content';
import { scrollToSection } from '../../utils/scroll';

export default function Header({ onNewReport }) {
  const [menuOpen, setMenuOpen] = useState(false);

  const goToPanel = () => {
    setMenuOpen(false);
    scrollToSection('painel-servidor');
  };

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/90 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="flex items-center gap-3 text-left">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-navy text-xl text-brand-emeraldLight shadow-md">
              <i className="fa-solid fa-city" />
            </span>
            <span>
              <span className="block text-xl font-bold leading-none tracking-tight text-brand-navy">
                Conecta <span className="text-brand-emerald">Recife</span>
              </span>
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Inteligência Urbana</span>
            </span>
          </button>

          <nav className="hidden items-center space-x-8 text-sm font-semibold text-slate-700 md:flex">
            {NAV_LINKS.map((link) => (
              <a key={link.id} href={`#${link.id}`} className="transition-colors hover:text-brand-emerald">
                {link.label}
              </a>
            ))}
          </nav>

          <div className="hidden items-center gap-3 sm:flex">
            <button onClick={goToPanel} className="rounded-full px-5 py-2.5 text-sm font-semibold text-brand-navy transition-all hover:text-brand-emerald">
              Entrar
            </button>
            <button onClick={onNewReport} className="rounded-full bg-brand-emerald px-6 py-2.5 text-sm font-semibold text-white shadow-md shadow-brand-emerald/20 transition-all hover:-translate-y-0.5 hover:bg-brand-emeraldHover">
              Começar agora
            </button>
          </div>

          <button
            onClick={() => setMenuOpen((open) => !open)}
            aria-label="Abrir menu"
            aria-expanded={menuOpen}
            className="rounded-lg p-2 text-slate-600 hover:text-slate-900 md:hidden"
          >
            <i className={`fa-solid ${menuOpen ? 'fa-xmark' : 'fa-bars'} text-xl`} />
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className="space-y-3 border-b border-slate-200 bg-white px-4 pb-6 pt-2 md:hidden">
          {NAV_LINKS.map((link) => (
            <a key={link.id} href={`#${link.id}`} onClick={() => setMenuOpen(false)} className="block py-2 font-medium text-slate-700 hover:text-brand-emerald">
              {link.label}
            </a>
          ))}
          <div className="flex flex-col gap-2 border-t border-slate-100 pt-4">
            <button onClick={goToPanel} className="w-full rounded-full border border-slate-300 py-2.5 font-semibold text-slate-800">
              Acessar Painel
            </button>
            <button
              onClick={() => { setMenuOpen(false); onNewReport(); }}
              className="w-full rounded-full bg-brand-emerald py-2.5 font-semibold text-white"
            >
              Cadastrar Denúncia
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
