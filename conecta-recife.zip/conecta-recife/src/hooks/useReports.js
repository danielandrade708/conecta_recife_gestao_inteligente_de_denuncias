import { useMemo, useState } from 'react';
import { initialReports } from '../data/reports';
import { classifyUrgency, nextProtocol } from '../utils/triage';

const DEFAULT_FILTERS = { search: '', category: 'Todos', urgency: 'Todos' };

// Centraliza o estado das denúncias, filtros e indicadores.
export default function useReports() {
  const [allReports, setAllReports] = useState(initialReports);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);

  const updateFilter = (key, value) => setFilters((prev) => ({ ...prev, [key]: value }));
  const resetFilters = () => setFilters(DEFAULT_FILTERS);

  const visibleReports = useMemo(() => {
    const term = filters.search.toLowerCase();
    return allReports.filter(
      (r) =>
        (filters.category === 'Todos' || r.categoria === filters.category) &&
        (filters.urgency === 'Todos' || r.urgencia === filters.urgency) &&
        [r.id, r.bairro, r.categoria, r.descricao].some((field) => field.toLowerCase().includes(term))
    );
  }, [allReports, filters]);

  const stats = useMemo(() => {
    const open = allReports.filter((r) => r.status !== 'Resolvido');
    return {
      total: allReports.length,
      critical: open.filter((r) => r.urgencia === 'Alta').length,
      pending: open.length,
      solved: allReports.length - open.length,
    };
  }, [allReports]);

  const addReport = ({ categoria, bairro, descricao }) =>
    setAllReports((prev) => [
      {
        id: nextProtocol(prev), categoria, bairro, descricao,
        urgencia: classifyUrgency(descricao),
        status: 'Em Aberto',
        recomendacao: 'Triagem automática concluída. Encaminhar para a secretaria competente.',
      },
      ...prev,
    ]);

  const resolveReport = (id) =>
    setAllReports((prev) => prev.map((r) => (r.id === id ? { ...r, status: 'Resolvido' } : r)));

  return { allReports, visibleReports, stats, filters, updateFilter, resetFilters, addReport, resolveReport };
}
