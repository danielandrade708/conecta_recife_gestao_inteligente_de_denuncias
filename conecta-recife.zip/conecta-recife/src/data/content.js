// Conteúdo estático da página (navegação, categorias, textos de seções).

export const NAV_LINKS = [
  { id: 'inicio', label: 'Início' },
  { id: 'visao-geral', label: 'Visão Geral' },
  { id: 'ods-impacto', label: 'ODS & Impacto' },
  { id: 'painel-servidor', label: 'Painel do Servidor' },
  { id: 'sobre', label: 'Sobre' },
];

export const CATEGORIES = [
  { value: 'Iluminação Pública', short: 'Iluminação', icon: 'fa-lightbulb', color: 'text-amber-500' },
  { value: 'Limpeza Urbana', short: 'Limpeza', icon: 'fa-trash-can', color: 'text-emerald-500' },
  { value: 'Mobilidade', short: 'Mobilidade', icon: 'fa-bus', color: 'text-blue-500' },
  { value: 'Meio Ambiente', short: 'Meio Ambiente', icon: 'fa-tree', color: 'text-green-600' },
  { value: 'Ordenamento', short: 'Ordenamento', icon: 'fa-building-user', color: 'text-purple-500' },
];

export const BAIRROS = ['Boa Viagem', 'Casa Amarela', 'Várzea', 'Santo Amaro', 'Espinheiro', 'Ibura', 'Madalena'];

export const FEATURES = [
  {
    icon: 'fa-filter-circle-dollar',
    title: 'Triagem & Priorização',
    text: 'Classificação automatizada baseada em severidade e risco. Reduz o esforço manual da gestão ao priorizar chamados críticos em tempo real.',
  },
  {
    icon: 'fa-map-location-dot',
    title: 'Recorrência Territorial',
    text: 'Mapeamento de manchas de calor nos bairros do Recife (ex: Boa Viagem, Várzea, Casa Amarela) identificando reincidências de problemas urbanos.',
  },
  {
    icon: 'fa-chart-line',
    title: 'Uso Estratégico de Dados',
    text: 'Transformação de denúncias isoladas em inteligência preventiva para ações proativas da prefeitura antes do agravamento do problema.',
  },
];

export const ODS_GOALS = [
  {
    number: 11,
    title: 'Cidades e Comunidades Sustentáveis',
    text: 'Tornar as cidades e os assentamentos humanos inclusivos, seguros, resilientes e sustentáveis. A rápida resolução de falhas de infraestrutura pública reduz vulnerabilidades urbanas no Recife.',
    goal: 'Meta 11.3 • Urbanização Inclusiva & Gestão Participativa',
    box: 'bg-amber-600',
    tag: 'border-amber-500/30 bg-amber-500/20 text-amber-300',
  },
  {
    number: 16,
    title: 'Paz, Justiça e Instituições Eficazes',
    text: 'Promover sociedades pacíficas e inclusivas, proporcionar o acesso à justiça para todos e construir instituições eficazes, responsáveis e transparentes em todos os níveis.',
    goal: 'Meta 16.6 • Instituições Eficazes e Transparentes',
    box: 'bg-blue-700',
    tag: 'border-blue-500/30 bg-blue-500/20 text-blue-300',
  },
];
