// Denúncias simuladas do Conecta Recife.
export const initialReports = [
  {
    id: 'REC-2026-881', categoria: 'Iluminação Pública', bairro: 'Boa Viagem', urgencia: 'Alta', status: 'Em Aberto',
    descricao: 'Lâmpadas apagadas em sequência na orla próximo ao Posto 3. Risco à segurança no período noturno.',
    recomendacao: 'Encaminhar equipe de manutenção de iluminação de urgência (Plantão Noturno).',
  },
  {
    id: 'REC-2026-882', categoria: 'Limpeza Urbana', bairro: 'Casa Amarela', urgencia: 'Alta', status: 'Em Análise',
    descricao: 'Acúmulo atípico de entulhos obstruindo galeria de águas pluviais próximo ao mercado público.',
    recomendacao: 'Despachar caminhão de sucção e equipe de capinação preventiva para evitar alagamento.',
  },
  {
    id: 'REC-2026-883', categoria: 'Mobilidade', bairro: 'Várzea', urgencia: 'Média', status: 'Em Aberto',
    descricao: 'Semáforo piscando em amarelo no cruzamento da Av. Caxangá com a rua principal.',
    recomendacao: 'Notificar CTTU para reparo de placa controladora do semáforo.',
  },
  {
    id: 'REC-2026-884', categoria: 'Meio Ambiente', bairro: 'Santo Amaro', urgencia: 'Baixa', status: 'Resolvido',
    descricao: 'Árvore de grande porte necessitando de poda preventiva de galhos baixos.',
    recomendacao: 'Vistoria concluída e poda agendada/realizada pela EMLURB.',
  },
  {
    id: 'REC-2026-885', categoria: 'Ordenamento', bairro: 'Espinheiro', urgencia: 'Média', status: 'Em Análise',
    descricao: 'Ocupação irregular de calçada dificultando a acessibilidade de pedestres e cadeirantes.',
    recomendacao: 'Agendar fiscalização de posturas do município.',
  },
  {
    id: 'REC-2026-886', categoria: 'Limpeza Urbana', bairro: 'Ibura', urgencia: 'Alta', status: 'Em Aberto',
    descricao: 'Descarte irregular em encosta próximo ao canal. Risco de deslizamento na chuva.',
    recomendacao: 'Prioridade Máxima: Remoção mecânica imediata de resíduos pesados.',
  },
];
