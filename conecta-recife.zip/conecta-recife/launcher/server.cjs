// Servidor local que entrega a pasta dist/ e abre o navegador.
// É o ponto de entrada do executável (.exe) gerado com `npm run build:exe`.
const http = require('http');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const DIST = path.join(__dirname, '..', 'dist');
const DEFAULT_PORT = Number(process.env.PORT) || 4173;

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf',
};

const server = http.createServer((req, res) => {
  const requested = path.join(DIST, path.normalize(decodeURIComponent(req.url.split('?')[0])));
  if (!requested.startsWith(DIST)) {
    res.writeHead(403);
    return res.end();
  }

  const send = (file, status = 200) =>
    fs.readFile(file, (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end('Não encontrado');
      }
      res.writeHead(status, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
      res.end(data);
    });

  fs.stat(requested, (err, stat) => {
    if (!err && stat.isFile()) return send(requested);
    // Rotas sem extensão voltam para o index.html (aplicação de página única).
    if (path.extname(requested)) {
      res.writeHead(404);
      return res.end('Não encontrado');
    }
    send(path.join(DIST, 'index.html'));
  });
});

const openBrowser = (url) => {
  const cmd = { win32: `start "" "${url}"`, darwin: `open "${url}"` }[process.platform] || `xdg-open "${url}"`;
  exec(cmd);
};

const start = (port) => {
  server.once('error', (e) => {
    if (e.code === 'EADDRINUSE' && port !== 0) return start(0); // porta ocupada: escolhe outra
    throw e;
  });
  server.listen(port, '127.0.0.1', () => {
    const url = `http://127.0.0.1:${server.address().port}`;
    console.log(`Conecta Recife rodando em ${url}`);
    console.log('Mantenha esta janela aberta. Feche-a para encerrar o programa.');
    if (!process.env.NO_OPEN) openBrowser(url);
  });
};

start(DEFAULT_PORT);
