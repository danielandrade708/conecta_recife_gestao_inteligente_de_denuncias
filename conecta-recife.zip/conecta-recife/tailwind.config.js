export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['"Inter Variable"', 'Inter', 'sans-serif'] },
      colors: {
        brand: {
          navy: '#0F172A',
          lightBg: '#F8FAFC',
          emerald: '#10B981',
          emeraldLight: '#34D399',
          emeraldHover: '#059669',
          softMint: '#ECFDF5',
        },
      },
    },
  },
  plugins: [],
};
